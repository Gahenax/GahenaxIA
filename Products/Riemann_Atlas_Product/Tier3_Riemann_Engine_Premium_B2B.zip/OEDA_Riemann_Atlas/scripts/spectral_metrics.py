import pandas as pd
import numpy as np

def load_atlas_data(filepath="data/riemann_zeros_v1.parquet"):
    """
    Loads the Riemann Spectrum Atlas dataset.
    Falls back to CSV if Parquet is not available.
    """
    try:
        df = pd.read_parquet(filepath)
    except FileNotFoundError:
        csv_path = filepath.replace(".parquet", ".csv")
        df = pd.read_csv(csv_path)
    return df

def calculate_nnsd(df):
    """
    Calculates the Nearest Neighbor Spacing Distribution (NNSD).
    Expects 'normalized_gap_s' column.
    """
    return df['normalized_gap_s'].values

def wigner_surmise(s):
    """
    Theoretical GUE Wigner Surmise prediction for spacing s.
    """
    return (32.0 / np.pi**2) * (s**2) * np.exp(-4.0 * (s**2) / np.pi)

def gue_variance(L):
    """
    Number Variance Sigma^2(L) for GUE.
    """
    # Approximation for L > 1
    return (1 / np.pi**2) * (np.log(2 * np.pi * L) + np.euler_gamma + 1 - np.pi**2 / 8)
