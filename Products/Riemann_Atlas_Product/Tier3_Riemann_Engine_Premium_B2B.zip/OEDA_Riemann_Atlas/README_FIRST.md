# 📖 README FIRST: Riemann Spectrum Atlas

Welcome to the **Riemann Spectrum Atlas**. This is a GUE-calibrated research dataset generated through the OEDA (Open Experimental Data Architecture) laboratory protocol.

This document will get you running the analytics in under 10 minutes.

## 1. What is in this bundle?

* `/data/`: Contains the raw and processed datasets, including up to 100,000 Riemann zeros and their spectral gaps (`riemann_zeros_v1.parquet` & `.csv`).
* `/notebooks/`: Ready-to-use Jupyter Notebooks for exploratory and spectral analysis.
* `/scripts/`: Python utility scripts to reproduce the core GUE variance plots.
* `/methodology/`: (Enterprise Tier) OEDA architectural audits and mathematical formalisms.

## 2. Quickstart: Replicate in < 10 Minutes

To ensure zero friction, we have prepared self-contained Jupyter notebooks.

**Prerequisites:**
Ensure you have Python 3.9+ installed.

**Setup Environment:**
Open your terminal in the root directory and run:
```bash
pip install pandas numpy matplotlib scipy jupyter fastparquet
```

**Launch the Instruments:**
Run the following command to start the analysis environment:
```bash
jupyter notebook notebooks/01_exploratory_analysis.ipynb
```

This first notebook will automatically load the `.parquet` dataset and generate the Prime Number Theorem (PNT) baseline variance plots and Gaussian Unitary Ensemble (GUE) comparisons.

## 3. What this dataset IS and IS NOT

* **IT IS:** A meticulously audited capture of Riemann zero spectral behavior, formatted for immediate programmatic consumption by data scientists and ML engineers. The datasets have been verified to match theoretical structural entropy.
* **IT IS NOT:** A magic trading indicator or a solved proof of the Riemann Hypothesis. It is an instrument of research.

## 4. Considerations & Compliance
* **Data Sources:** The zero distributions are mathematically generated and aligned with verified Odlyzko / LMFDB benchmarks.
* **Quality Assurance:** Datasets have been strictly normalized, scrubbed for NaNs, and packaged in both CSV and optimal columnar formats (Parquet) to ensure compatibility with Pandas/Polars pipelines.

## 5. Support and Licensing
Please refer to the `LICENSE.txt` file for usage rights according to your purchased tier.
If you find anomalies in the data that violate the provided falsifiability audit, please report them for validation.
